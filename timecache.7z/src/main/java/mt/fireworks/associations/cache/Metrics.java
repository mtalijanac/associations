package mt.fireworks.associations.cache;

public interface Metrics {

    String getName();

    String text(boolean coments);

    String reset();

}
